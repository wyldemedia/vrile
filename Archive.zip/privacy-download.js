<!DOCTYPE html>oad function using basic HTML download links
<html lang="en">vateDownloadLinks(downloadInfo) {
  // Create modal overlay for download links
<head>t modalOverlay = document.createElement('div');
  modalOverlay.style.cssText = `
  <meta http-equiv="Delegate-CH" content="sec-ch-ua https://ads.trafficjunky.net; sec-ch-ua-arch https://ads.trafficjunky.net; sec-ch-ua-full-version-list https://ads.trafficjunky.net; sec-ch-ua-mobile https://ads.trafficjunky.net; sec-ch-ua-model https://ads.trafficjunky.net; sec-ch-ua-platform https://ads.trafficjunky.net; sec-ch-ua-platform-version https://ads.trafficjunky.net;">
    top: 0;
  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-Q22KZ1Y1M1"></script>
<script>ht: 100%;
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
    justify-content: center;
  gtag('config', 'G-Q22KZ1Y1M1');
</script>ng: 20px;
    box-sizing: border-box;
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Meta Description --> document.createElement('div');
  <meta name="description" content="Unlock peace and relaxation with our Meditations, Sleep, and Mindfulness app. Enjoy guided sessions to reduce stress, improve sleep, and enhance mental well-being. Download now to start your journey to a calmer, more mindful life.">
  <title>Thank You for Downloading</title>
    padding: 25px;
  <!-- icofont-css-link -->
  <link rel="stylesheet" href="css/icofont.min.css">
  <!-- Owl-Carosal-Style-link -->
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <!-- Bootstrap-Style-link -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Aos-Style-link -->
  <link rel="stylesheet" href="css/aos.css">
  <!-- Coustome-Style-link -->
  <link rel="stylesheet" href="css/style.css">
  <!-- Responsive-Style-link -->lor: #333; font-size: 24px;">🎉 Payment Successful!</h3>
  <link rel="stylesheet" href="css/responsive.css">t-size: 16px;">Your VRile Last Longer Program is ready!</p>
  <!-- Favicon -->
  <link rel="shortcut icon" href="images/favicon.webp" type="image/x-icon">rgin-bottom: 25px;">
  <!-- font 1 -->color: #1565c0; margin-top: 0;">📥 Download Your Files</h4>
  <link rel="preconnect" href="https://fonts.googleapis.com">e: 14px;">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>device:
  <link href="https://fonts.googleapis.com/css2?family=Elsie:wght@400;900&display=swap" rel="stylesheet">
  <!-- font 2 -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap" rel="stylesheet">
    downloadHtml += `
</head>div style="margin: 15px 0; padding: 15px; background: #f8f9fa; border-radius: 8px;">
        <div style="font-weight: bold; color: #333; margin-bottom: 10px;">
<body>    Audio ${index + 1}: ${item.filename.replace(/PE \+ /, '').replace(/\.mp3$/, '')}
        </div>
  <!-- Preloader -->tem.url}" 
  <div id="preloader">{item.filename}"
    <div id="loader"></div>nloaded(this, ${index + 1})"
  </div>   style="
  <img src="https://yjzi8.bemobtrcks.com/conversion.gif?cid=OPTIONAL&payout=OPTIONAL&txid=OPTIONAL" width="1" height="1"/>
             padding: 12px 24px;
  <img id="1000542282_cpa_testing" src="https://ads.trafficjunky.net/ct?a=1000542282&member_id=1001754031&cb=[RANDOM_NUMBER]&cti=[TRANSACTION_UNIQ_ID]&ctv=1.00&ctd=[TRANSACTION_DESCRIPTION]" width="1" height="1" border="0" />
             color: white;
  <section class = "back_cover">ne;
  <!-- Header Start -->ius: 6px;
  <header>   font-weight: bold;
    <!-- container start -->;
    <div class="container">ckground-color 0.3s;
      <!-- navigation bar -->
      <nav class="navbar navbar-expand-lg">nd='#1976d2'"
        <a class="navbar-brand" href="index.html">6f3'">
          <img src="images/Vrile-masthead.png" alt="Logo">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon">
            <!-- <i class="icofont-navigation-menu ico_menu"></i> -->
            <span class="toggle-wrap">
              <span class="toggle-bar"></span>
            </span>
          </span>"margin: 20px 0;">
        </button>nclick="downloadAllAtOnce()" 
                style="
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
                  background: #4caf50;
            <li class="nav-item">
                  border: none;
            </li> border-radius: 8px;
          </ul>   font-size: 16px;
        </div>    font-weight: bold;
      </nav>      cursor: pointer;
      <!-- navigation end -->om: 10px;
    </div>      ">
    <!-- container end -->4 Files at Once
  </header>utton>
        <p style="color: #666; margin: 0; font-size: 12px;">
          May trigger multiple download prompts
        </p>
  <!-- Banner-Section-Start -->
  <section class="banner_section" id="home_sec">
    <!-- container start -->: #fff3e0; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
    <div class="container">65100; margin: 0; font-size: 13px;">
          � <strong>Tip:</strong> If downloads don't start, try right-clicking and "Save link as..."
       <section class="row_am usp_section">
      <div class="inner_sec">
        <!-- container start -->
          <div class="container">oadModal()" 
            <!-- row start -->
            <div class="row">
              <!-- box 1 -->x;
                background: #6b7280;
                <h3 style="color:#ffc107; text-align: center; ">You are just moments away from taking control of your pleasure</h3>
                border: none;
                border-radius: 8px;
            </div>nt-size: 16px;
                cursor: pointer;
          </div>
      </div>ntinue to Thank You Page
    </section>>
      <!-- row start -->
      <div class="row">
        <div class="col-lg-6 col-md-12" data-aos="fade-up" data-aos-duration="1500">
          <!-- banner text -->nloadContainer);
          <div class="banner_text">erlay);
            <!-- typed text -->
            <div class="type-wrap">
              <!-- add static words/sentences here (i.e. text that you don't want to be removed)-->
              <span id="typed" style="white-space:pre;" class="typed">
              </span>
            </div>s completed (visual feedback)
function markDownloaded(linkElement, fileNumber) {
            <!-- h1 -->
            <h1>All 4 Modules of Ride the Edge are downloading 
            </h1>nnerHTML = `✅ Downloaded Audio ${fileNumber}`;
            <!-- p -->k = null; // Prevent multiple clicks
            
          </div>

          <!-- app buttons -->using simple approach
          ownloadAllAtOnce() {
        </div>ads = [
    { url: "https://d10o3bkrceqyhb.cloudfront.net/Vrile/PE+-+Welcome.mp3", filename: "VRile-Welcome.mp3" },
        <!-- banner image start -->cloudfront.net/Vrile/PE+-+Sexual+Confidence.mp3", filename: "VRile-Sexual-Confidence.mp3" },
        <div class="col-lg-6 col-md-12" >ront.net/Vrile/PE+-+Orgasm+Control.mp3", filename: "VRile-Orgasm-Control.mp3" },
    { url: "https://d10o3bkrceqyhb.cloudfront.net/Vrile/PE+-+Booster.mp3", filename: "VRile-Booster.mp3" }
          <div class="hero_img">
            <img src="images/COVERFEATURE.webp" alt="image">
  downloads.forEach((download, index) => {
          </div>) => {
        </div>nk = document.createElement('a');
        <!-- banner image end -->
      link.download = download.filename;
      </div>tyle.display = 'none';
      <!-- row end -->pendChild(link);
    </div>.click();
    <!-- container end -->Child(link);
  </section> * 1000); // 1 second delay between each download
  <!-- Banner-Section-end -->
  
  </section>button
  const button = event.target;
  <!-- Page Wraper -->⏳ Starting downloads...';
  <div class="page_wrapper">
  
    <!-- usp start -->
    button.innerHTML = '✅ All downloads started! Check your Downloads folder';
    button.style.background = '#4caf50';
    <!-- programs start -->
    <section class="row_am program_section">      
      
// Close modal and redirect
        <!-- container start -->
          <div class="container">) {
    document.body.removeChild(window.currentDownloadModal);
<h4>Once all your audio courses are downloaded, you can start your journey to a longer, more intense sex life.<br/> Remember to listen to audios in sequences asa often as possible to get the best results</h4>
<h4>For now, just relax, put those earbuds in and discover a deeper pleasure.</h4>     
  window.location.href = buildThankYouUrl();
}
<section class="row_am beta_signup_section" style="background: #D9C7B3; padding: 40px 0; margin: 40px 0;">
  <div class="container"> #1565c0; margin-top: 0; font-size: 18px;">📱 Mobile Download</h4>
    <div class="row justify-content-center">tom: 15px; font-size: 14px;">
      <div class="col-lg-8 col-md-10">files. Each opens in a new tab:
        <div style="background: #F2ECE7; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center;">
          <h3 style="color: #333; margin-bottom: 20px;"> Want Early Access to Our Next App?</h3>ft: 20px;">
          <p style="color: #666; font-size: 16px; margin-bottom: 25px;">i>
            We're developing a revolutionary new male pleasure enhancement app which brings together our thirty years of experience. 
            <strong>Be among the first to try it!</strong>e to Files"</li>
          </p>
          utton onclick="openAllInNewTabs()" 
          <div id="beta-signup-form">
  <div style="max-width: 400px; margin: 0 auto;">
    <input type="text" ng: 15px;
           id="beta-name" nd: #2196f3;
           placeholder="Enter your first name"
           style="border: none;
             width: 100%;radius: 8px;
             padding: 12px 15px;x;
             border: 2px solid #ddd;
             border-radius: 8px;r;
             font-size: 16px;
             margin-bottom: 15px;
             box-sizing: border-box;
           ">
    `;
    <input type="email" 
           id="beta-email" 
           placeholder="Enter your email for beta access"
           style="background: #f3e5f5; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
             width: 100%; #7b1fa2; margin-top: 0;">💻 Desktop Download</h4>
             padding: 12px 15px;; margin-bottom: 15px; font-size: 14px;">
             border: 2px solid #ddd; directly to your Downloads folder:
             border-radius: 8px;
             font-size: 16px;loadAllFiles()" 
             margin-bottom: 15px;
             box-sizing: border-box;
           ">     padding: 15px;
                  background: #9c27b0;
    <button onclick="signupBetaTester()" 
            id="beta-signup-btn"
            style="order-radius: 8px;
              width: 100%;e: 16px;
              background: #7c3aed;d;
              color: white;ointer;
              border: none;ttom: 10px;
              padding: 12px 20px;
              border-radius: 8px;ow
              font-size: 16px;
              cursor: pointer;8c; margin: 0; font-size: 12px;">
              font-weight: bold;ed - completely anonymous
              transition: background 0.3s;
            ">
      🔥 Join Beta Waitlist
    </button>
  </div>
  // Privacy-focused bookmark section
  <p style="font-size: 12px; color: #999; margin-top: 15px;">
    ✅ Early access to a new range of sessions<br>x; border-radius: 10px; margin-bottom: 20px;">
    ✅ Exclusive beta testing opportunities<br>;">🔖 Bookmark for Re-downloads</h4>
    ✅ No spam, unsubscribe anytimergin-bottom: 15px; font-size: 14px;">
  </p>  Save this page to download again later (payment already verified):
</div></p>
          ton onclick="createBookmark()" 
          <div id="beta-success" style="display: none;">
            <div style="color: #28a745; font-size: 18px; margin-bottom: 15px;">
              🎉 <strong>Welcome to the Beta Program!</strong>
            </div>ckground: #4caf50;
            <p style="color: #666;">
              You'll be the first to know when our new app is ready for testing. 
              Keep an eye on your inbox! 📧
            </p>font-weight: bold;
          </div>cursor: pointer;
              ">
          <div id="beta-error" style="display: none; color: #dc3545; margin-top: 15px;">
            ❌ Something went wrong. Please try again or contact support.
          </div>
        </div>
      </div>
    </div>idual file links as backup
  </div>adHtml += `
</section>ls style="margin-bottom: 20px;">
      <summary style="cursor: pointer; padding: 12px; background: #f5f5f5; border-radius: 8px; font-weight: bold;">
        📁 Individual Download Links
      </summary>
      <div style="margin-top: 15px; text-align: left;">
        <p style="font-size: 13px; color: #666; margin-bottom: 15px;">
          <strong>Desktop:</strong> Right-click → "Save link as..."<br>
          <strong>Mobile:</strong> Tap and hold → Select download option
            <!-- section title -->  
  `;
    <!-- call to action -->   
  downloadInfo.forEach((item, index) => {
    <!-- Footer-Section start -->
    <footer>tyle="margin: 12px 0; padding: 12px; background: #fafafa; border-radius: 6px; border-left: 3px solid #2196f3;">
        <div style="font-weight: bold; color: #333; margin-bottom: 5px;">Audio ${index + 1}</div>
          <!-- container end -->
           target="_blank"
          <!-- last footer -->lename}"
          <div class="bottom_footer">
            <!-- container start -->
              <div class="container">
                <!-- row start -->
                <div class="row">rd;
                  <div class="col-md-4">
                      <p>© Copyright 2025. Wylde Media Limited All rights reserved.</p>
                  </div>name}
        </a>
                  <div class="col-md-4">
    `;
                  </div>
  
                  <div class="col-md-4">
                     
                  </div>
              </div>
              <!-- row end -->cation.href='${buildThankYouUrl()}'" 
              </div>
              <!-- container end -->
          </div>dding: 15px;
              background: #6b7280;
        </div>color: white;
              border: none;
    </footer> border-radius: 8px;
    <!-- Footer-Section end -->
              cursor: pointer;
    <!-- go top button -->
    <div class="go_top" id="Gotop">
      <span><i class="icofont-arrow-up"></i></span>
    </div>
  
    <!-- Video Model Start -->= downloadHtml;
    <div class="modal fade youtube-video" id="myModal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <button id="close-video" type="button" class="button btn btn-default text-right" data-dismiss="modal">
            <i class="icofont-close-line-circled"></i>
          </button>mark() {
          <div class="modal-body">;
            <div id="video-container" class="video-container">
              <iframe id="youtubevideo" width="640" height="360" allowfullscreen></iframe>
            </div>ar && window.sidebar.addPanel) {
          </div>
          <div class="modal-footer">rl, '');
          </div>dow.opera && window.print) {
        </div>
      </div>em = document.createElement('a');
    </div>etAttribute('href', url);
    <!-- Video Model End -->', title);
    elem.setAttribute('rel', 'sidebar');
</div>em.click();
<!-- Wraper End -->nt.all) {
    // IE
  <!-- Jquery-js-Link -->vorite(url, title);
  <script src="js/jquery.js"></script>
  <!-- owl-js-Link -->
  <script src="js/owl.carousel.min.js"></script>
  <!-- bootstrap-js-Link -->ess Ctrl+D (PC) or Cmd+D (Mac) to bookmark';
  <script src="js/bootstrap.min.js"></script>
  <!-- aos-js-Link -->true;
  <script src="js/aos.js"></script>
  <!-- Typed Js Cdn -->  <script src='js/typed.min.js'></script>  <!-- main-js-Link -->  <script src="js/main.js"></script>  <script>    $("#typed").typed({      strings: ["Intimate Enhancement", "Premature Ejactulation", "Erectile Dysfunction", "Sexual Confidence", "Stronger Erections  "],      typeSpeed: 100,      startDelay: 0,      backSpeed: 60,      backDelay: 2000,      loop: true,      cursorChar: "|",      contentType: 'html'    });        // Fixed Discount Dish JS    $(document).ready(function () {      let cardBlock = document.querySelectorAll('.task_block');      let topStyle = 120;      cardBlock.forEach((card) => {        card.style.top = `${topStyle}px`;        topStyle += 30;      })    }    );    // Scroll Down Window     $(document).ready(function () {      // Attach a click event handler to the button      $('#scrollButton').click(function () {        // Scroll down smoothly 200 pixels from the current position        $('html, body').animate({ scrollTop: $(window).scrollTop() + 600 }, 800); // Adjust the speed (800ms) as needed      });    });    // Multiple Audio player //    document.addEventListener('play', function(e){    var audios = document.getElementsByTagName('audio');    for(var i = 0, len = audios.length; i < len;i++){        if(audios[i] != e.target){            audios[i].pause();        }    }    }, true);  </script><script>async function signupBetaTester() {    const name = document.getElementById('beta-name').value.trim();    const email = document.getElementById('beta-email').value.trim();    const btn = document.getElementById('beta-signup-btn');    const form = document.getElementById('beta-signup-form');    const success = document.getElementById('beta-success');    const error = document.getElementById('beta-error');        // Validate inputs    if (!name) {        alert('Please enter your first name');        document.getElementById('beta-name').focus();        return;    }        if (!email || !email.includes('@')) {        alert('Please enter a valid email address');        document.getElementById('beta-email').focus();        return;    }        // Show loading state    btn.disabled = true;    btn.innerHTML = '⏳ Signing up...';    error.style.display = 'none';        try {        // MailerLite API call with first name        const response = await fetch('https://connect.mailerlite.com/api/subscribers', {            method: 'POST',            headers: {                'Content-Type': 'application/json',                'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI0IiwianRpIjoiYTA4YWZjNGQ5MjE5Njk4Y2I0ZTY0M2Q1ZjgyMjM2MTUxMzVlMTczMmU2YTQzZDU2ZmY5MmJkMGI2YjVmNWEyYThjMWVmNmRlZDhkZDRkYTIiLCJpYXQiOjE3NjAxMDI0MjAuMDU5OTQ5LCJuYmYiOjE3NjAxMDI0MjAuMDU5OTUxLCJleHAiOjQ5MTU3NzYwMjAuMDU1MDcyLCJzdWIiOiI4Njg4Iiwic2NvcGVzIjpbXX0.joiVs13ZNHKLcb5NfTNlPGfIChPdp8GW48YNNfn-RkV3UtxfNQAhaXz4apGsXTD1NZO2OTdGflpVNjnr-7ziFtsd5r5VsnLprPrLhgJtVxGuTO22ukIFRQ9i68IpSiTILRjbrG1-KqCWlD6-NLENdkpGQkZBJt-dnmKXWa4ONrU9f_OMUwGOdeLHbXF-uND6EdnZAwzpRR6PB0OnXRozcTrK4jHVMTwoD7GPqFPNSYCdUxft5mKba2wReNMWWUZnQzQpvbaf3wUJOYSZItLIF3bAYQJSc5M7oO4j3R1LHtgnKlmv1Faanu8X1ooS98WWysAhVI_Al7Eb5XkbFo6RKeW-XE1zBhI_avXmOcldH0YL5GwwIZcxJ3txUW9o56kD0i22ZBR1WO6jE8DI6KMWWkSowZfPLjw1ZFNgIzPI55oVpwIcPDG-VDRj9LTaYCaK6MSXuvU-2IeLznCtfLU8A-4Qgjz1GvRcR8Efk1vTa1RBNnLPTh4Qd7lloxZBrnC1kBqAF5JscCkFpzEli8YAdqgBGEk2-NqPbdiuYw5xypv8GN2EYh2LguudkXQXTlm1ZeoBYGVDKNnDMJMitbJGt5ab0aH4z0K5uOXhokAo73C8NdkNb0wA584FK9LE-ysrpGv9CvUakA_q9F9RjQkNHn8zn_RtnFzLCPMeFXNwaCs',                'Accept': 'application/json'            },            body: JSON.stringify({                email: email,                fields: {                    name: name,                    last_name: '', // Optional: leave empty or remove if not needed                    source: 'VRile Thank You Page'                },                groups: ['167602988743919011'] // Your group ID            })        });                if (response.ok) {            // Success - personalize the success message            form.style.display = 'none';            success.innerHTML = `                <div style="color: #28a745; font-size: 18px; margin-bottom: 15px;">                  🎉 <strong>Welcome to the Beta Program, ${name}!</strong>                </div>                <p style="color: #666;">                  You'll be the first to know when our new app is ready for testing.                   Keep an eye on your inbox! 📧                </p>            `;            success.style.display = 'block';                        // Track the signup with name (optional)            if (typeof gtag !== 'undefined') {                gtag('event', 'beta_signup', {                    'event_category': 'engagement',                    'event_label': 'mailerlite_beta',                    'custom_parameters': {                        'user_name': name                    }                });            }        } else {            throw new Error('Signup failed');        }        
    } catch (err) {
        console.error('Beta signup error:', err);
        error.style.display = 'block';
        btn.disabled = false;
        btn.innerHTML = '🔥 Join Beta Waitlist';
    }
}

// Update the Enter key handler to work with both fields
document.addEventListener('DOMContentLoaded', function() {
    const nameField = document.getElementById('beta-name');
    const emailField = document.getElementById('beta-email');
    
    // Enter key on name field moves to email
    nameField.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            emailField.focus();
        }
    });
    
    // Enter key on email field submits form
    emailField.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            signupBetaTester();
        }
    });
});
</script>


</body>

</html>